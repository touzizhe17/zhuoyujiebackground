<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:33:"./themes/default/index\index.html";i:1492577733;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Open Source BMS</title>
    <meta name="description" content="Open Source BMS，全称Open Source Background System，基于ThinkPHP5开发的开源后台管理系统">
    <link rel="stylesheet" href="__JS__/layui/css/layui.css">
    <style>
        .header {
            width: 100%;
            height: 400px;
            background: url(__STATIC__/images/login-bg.png) #56bc94;
            text-align: center;
        }

        .header .top-nav {
            height: 60px;
            background-color: rgba(255, 255, 255, 0.3);
        }

        .header .top-nav h1 {
            display: inline-block;
            width: 300px;color: #fff;
            position: absolute;
            left: 0;
            top: 0;
            font-size: 24px;
            line-height: 60px;
            text-align: left;
        }

        .header .top-nav .layui-nav {
            position: absolute;
            top: 0;right: 0;
            width: 600px;
            text-align: right;
            background: none;
        }
        .header .top-nav .layui-nav a {color: #fff;}
        .header .download-btn {
            display: inline-block;
            width: 200px;
            height: 60px;
            line-height: 60px;
            margin-top: 150px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff;
            font-size: 18px;
            transition: all .3s;
        }
        .header .download-btn:hover {
            border-radius: 10px;
            background-color: rgba(255, 255, 255, 0.3);
        }

        .header .description {
            width: 200px;
            margin: 30px auto;
            text-align: left;
            color: #fff;
        }

        .content {margin-top: 50px;}
    </style>
</head>
<body>
<div class="header">
    <div class="top-nav">
        <div class="layui-main">
            <h1>Open Source BMS</h1>
            <ul class="layui-nav">
                <li class="layui-nav-item"><a href="">首页</a></li>
                <li class="layui-nav-item"><a href="http://opensourcebms.com/admin" target="_blank">后台演示</a></li>
                <li class="layui-nav-item"><a href="https://github.com/xiayulei/open_source_bms" target="_blank">GitHub</a></li>
            </ul>
        </div>
    </div>

    <a href="https://github.com/xiayulei/open_source_bms/releases/download/v1.1.1/open_source_bms_full_v1.1.1.zip" target="_blank" class="download-btn">下 载 （v1.1.1）</a>

    <div class="description">
        <iframe frameborder="0" src="http://ghbtns.com/github-btn.html?user=xiayulei&amp;repo=think_admin&amp;type=star&amp;count=true" width="90" height="20"></iframe>
        <iframe frameborder="0" src="http://ghbtns.com/github-btn.html?user=xiayulei&amp;repo=think_admin&amp;type=fork&amp;count=true" width="90" height="20"></iframe>
    </div>
</div>

<div class="layui-main content">
    <fieldset class="layui-elem-field">
        <legend>Open Source BMS</legend>
        <div class="layui-field-box">
            <h3 style="font-weight: bold;">Open Source BMS?</h3>
            <br />
            <p>全称Open Source Background Manager System，开源后台管理系统</p>
            <p>一个节省开发时间的后台管理系统，程序基于ThinkPHP 5开发，后台UI使用LayUI搭建。</p>
            <br />
            <br />

            <h3 style="font-weight: bold;">安装使用：</h3>
            <br />
            <p>
                * 方式一：git克隆下载，请执行`composer install`命令进行完整安装<br />
                * 方式二：非git用户请点击页面上方下载按钮下载完整版，完整版无须执行`composer install`命令<br />
                * 数据库文件为`open_source_bms.sql`<br />
                * 下载程序至本地，请搭建虚拟域名，并开启URL重写（必须）<br />
                * 站点开发前，建议修改`application`目录下的`config`配置文件，找到`salt`项，此项为全站加密公用盐值，请先修改，然后使用`md5('新密码' . config('salt'))`生成新密码，替换`admin_user`表中的默认管理员密码<br />
                * 默认后台账号 `admin`，密码`admin`<br />
            </p>
            <br />
            <br />

            <h3 style="font-weight: bold;">2017.4.19更新（v1.1.1)：</h3>
            <br />
            <p>
                * 核心框架同步更新为官方5.0.7<br />
                * 后台UI同步更新为官方1.0.9_rls<br />
                * 更换后台富文本编辑器为Ueditor 1.4.3.3<br />
                * 调整后台模板目录至themes目录下<br />
                * 入口文件移至根目录<br />
                * 重命名项目名为Open Source BMS<br />
                * 增加composer.lock文件<br />
                * 此版本功能方向无大变动，目的为修复BUG，下一版本会进行功能方向调整<br />
                * 修复一些BUG<br />
            </p>
            <br />
            <br />

            <h3 style="font-weight: bold;">2016.12.29更新（v1.1）：</h3>
            <br />
            <p>
                * 核心框架同步更新为官方5.0.4<br />
                * 后台UI同步更新为官方1.0.7<br />
                * 调整`model`模型目录至`common`公共目录<br />
                * 统一上传接口为`api`模块下`Upload`控制器<br />
                * 分类表增加path字段，优化子分类查询<br />
                * 增加单独密码修改功能，防止低权管理员随意修改自己权限组<br />
                * 更换后台富文本编辑器为KindEditor<br />
                * 恢复入口文件至public目录，减少整体结构调整<br />
                * 修复一些BUG<br />
            </p>
            <br />
            <br />
        </div>
    </fieldset>

    <p>2016-2017 © opensourcebms.com</p>
</div>

<script src="__JS__/layui/lay/dest/layui.all.js"></script>
<script>
    var element = layui.element();
</script>
</body>
</html>