<?php
namespace app\common\model;

use think\Db;
use think\Model;

class Link extends Model
{

}